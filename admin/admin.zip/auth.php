<?php
// auth.php - Authentication check

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include configuration and database
require_once __DIR__ . '/../php/config/config.php';
require_once __DIR__ . '/../php/config/database.php';

// If user_id is not set in the session, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>